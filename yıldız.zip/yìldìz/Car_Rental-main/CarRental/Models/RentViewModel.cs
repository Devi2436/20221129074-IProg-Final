﻿namespace CarRental.Models
{
    public class RentViewModel
    {
        public int CarId { get; set; }
    }

}
