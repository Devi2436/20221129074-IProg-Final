using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CarRental.Views.Car
{
    public class RentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
